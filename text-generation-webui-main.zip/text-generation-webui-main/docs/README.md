These files are a mirror of the documentation at:

# https://github.com/oobabooga/text-generation-webui/wiki

It is recommended to browse it there. Contributions can be sent here and will later be synced with the wiki.
