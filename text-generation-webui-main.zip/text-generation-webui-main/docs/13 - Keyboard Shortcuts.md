# Keyboard Shortcuts

#### General

| Shortcut                | Description                                      |
|-------------------------|--------------------------------------------------|
| Esc                     | Stop generation                                  |
| Tab                     | Switch between current tab and Parameters tab    |

#### Chat tab

| Shortcut                | Description                                      |
|-------------------------|--------------------------------------------------|
| Ctrl + S                | Show/hide chat controls                          |
| Ctrl + Enter            | Regenerate                                       |
| Alt + Enter             | Continue                                         |
| Ctrl + Shift + Backspace| Remove last                                      |
| Ctrl + Shift + K        | Copy last                                        |
| Ctrl + Shift + L        | Replace last                                     |
| Ctrl + Shift + M        | Impersonate                                      |
